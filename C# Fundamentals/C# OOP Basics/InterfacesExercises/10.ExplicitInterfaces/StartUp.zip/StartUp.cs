﻿using _10.ExplicitInterfaces.Core;
using System;

namespace _10.ExplicitInterfaces
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
